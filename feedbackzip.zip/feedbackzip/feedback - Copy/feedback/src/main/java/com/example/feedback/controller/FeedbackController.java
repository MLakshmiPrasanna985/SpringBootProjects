package com.example.feedback.controller;

import com.example.feedback.model.Feedback;
import com.example.feedback.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackRepository feedbackRepository;

    // Display the feedback form
    @GetMapping("/submit")
    public String showFeedbackForm() {
        return "feedback";
    }

    // Submit feedback
    @PostMapping("/submit")
    public String submitFeedback(@ModelAttribute Feedback feedback, Model model) {
        feedbackRepository.save(feedback);
        model.addAttribute("message", "Feedback submitted successfully");
        return "feedback";
    }

    // View feedback by faculty ID
    @GetMapping("/faculty")
    public String viewFeedback(@RequestParam String facultyId, Model model) {
        List<Feedback> feedbackList = feedbackRepository.findByFacultyId(facultyId);
        model.addAttribute("feedbackList", feedbackList);
        return "view-feedback";
    }
}
