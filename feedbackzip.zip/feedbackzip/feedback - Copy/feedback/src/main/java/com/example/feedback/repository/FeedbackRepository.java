package com.example.feedback.repository;

import com.example.feedback.model.Feedback;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface FeedbackRepository extends MongoRepository<Feedback, String> {
    List<Feedback> findByFacultyId(String facultyId);
}
