package com.example.feedback.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;
import java.util.Date;

@Data
@Document(collection = "feedback")
public class Feedback {
    @Id
    private String id;
    private String studentId;
    private String courseId;
    private String facultyId;
    private String feedback;
    private int rating;
    private Date date = new Date();
}
