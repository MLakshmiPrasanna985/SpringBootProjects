package com.example.Task11;


import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FoodItemService {

    private List<FoodItem> foodItems;

    public FoodItemService() {
        this.foodItems = new ArrayList<>();
        // Dummy data
        foodItems.add(new FoodItem(0L, "Chicken Biryani", 150.0, true));
        foodItems.add(new FoodItem(2L, "Veg Biryani", 120.0, true));
        foodItems.add(new FoodItem(3L, "Pasta", 100.0, true));
    }

    public List<FoodItem> getAllFoodItems() {
        return foodItems;
    }

    public FoodItem getFoodItem(Long id) {
        return foodItems.stream().filter(item -> item.getId().equals(id)).findFirst().orElse(null);
    }
}
