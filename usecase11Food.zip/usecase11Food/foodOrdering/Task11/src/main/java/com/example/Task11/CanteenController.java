package com.example.Task11;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class CanteenController {
    @Autowired
    private FoodItemService foodItemService;
    @Autowired
    private OrderService orderService;

    @GetMapping("/menu")
    public String showMenu(Model model) {
        List<FoodItem> foodItems = foodItemService.getAllFoodItems();
        model.addAttribute("foodItems", foodItems);
        return "menu";
    }

    @PostMapping("/order")
    public String placeOrder(@RequestParam Long[] itemIds, @RequestParam int[] quantities, Model model) {
        double totalAmount = 0;
        for (int i = 0; i < itemIds.length; i++) {
            FoodItem item = foodItemService.getFoodItem(itemIds[i]);
            if (item != null && item.isInStock()) {
                totalAmount += item.getPrice() * quantities[i];
            }
        }

        // Save Order (for demo purposes, we use a dummy student ID)
        Order order = new Order();
        order.setStudentId("dummyStudent");
        order.setTotalAmount(totalAmount);
        order.setStatus("Pending");
        orderService.saveOrder(order);

        // Redirect to payment process (dummy implementation)
        model.addAttribute("order", order);
        return "payment";
    }

    @PostMapping("/process-payment")
    public String processPayment(@RequestParam String paymentMethod, Model model) {
        // Dummy payment process
        // Integrate actual payment gateway here
        // ...

        // Redirect to menu after payment
        return "paymentSuccess";
    }
}
