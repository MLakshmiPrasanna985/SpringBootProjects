package com.example.Task14;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CoachService {
    @Autowired
    private CoachRepository coachRepository;

    public Coach createCoach(Coach coach) {
        return coachRepository.save(coach);
    }

    public Optional<Coach> getCoach(Long id) {
        return coachRepository.findById(id);
    }

    public void deleteCoach(Long id) {
        coachRepository.deleteById(id);
    }
}