package com.example.Task14;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/events")
public class EventController {
    @Autowired
    private EventService eventService;

    @GetMapping("/create")
    public String showCreateEventForm(Model model) {
        model.addAttribute("event", new Event());
        return "event_create"; // Thymeleaf template for creating an event
    }

    @PostMapping("/create")
    public String createEvent(@ModelAttribute Event event, Model model) {
        eventService.createEvent(event);
        model.addAttribute("message", "Event created successfully!");
        return "event_create"; // Redirect or show confirmation
    }

    @GetMapping("/{id}")
    public String getEvent(@PathVariable Long id, Model model) {
        model.addAttribute("event", eventService.getEvent(id).orElse(null));
        return "event_details"; // Thymeleaf template to show event details
    }

    @PostMapping("/delete/{id}")
    public String deleteEvent(@PathVariable Long id, Model model) {
        eventService.deleteEvent(id);
        model.addAttribute("message", "Event deleted successfully!");
        return "event_list"; // Thymeleaf template to show updated event list
    }
}
