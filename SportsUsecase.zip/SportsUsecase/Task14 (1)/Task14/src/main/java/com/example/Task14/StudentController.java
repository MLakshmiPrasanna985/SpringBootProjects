package com.example.Task14;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/students")
public class StudentController {
    
    @Autowired
    private StudentService studentService;

    // Show the registration form
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("student", new Student());
        return "student_register"; // Thymeleaf template for registration form
    }

    // Register a new student
    @PostMapping("/register")
    public String registerStudent(@ModelAttribute Student student, Model model) {
        studentService.registerStudent(student);
        model.addAttribute("message", "Registration successful!");
        return "student_register"; // Redirect or show confirmation
    }

    // View student details
    @GetMapping("/{id}")
    public String getStudent(@PathVariable Long id, Model model) {
        model.addAttribute("student", studentService.getStudent(id).orElse(null));
        return "student_details"; // Thymeleaf template to show student details
    }

    // Delete a student
    @PostMapping("/delete/{id}")
    public String deleteStudent(@PathVariable Long id, Model model) {
        studentService.deleteStudent(id);
        model.addAttribute("message", "Student deleted successfully!");
        return "student_list"; // Thymeleaf template to show updated student list
    }
}
