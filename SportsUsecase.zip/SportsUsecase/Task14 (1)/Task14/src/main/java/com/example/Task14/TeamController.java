package com.example.Task14;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/teams")
public class TeamController {
    @Autowired
    private TeamService teamService;

    @GetMapping("/create")
    public String showCreateTeamForm(Model model) {
        model.addAttribute("team", new Team());
        return "team_create"; // Thymeleaf template for creating a team
    }

    @PostMapping("/create")
    public String createTeam(@ModelAttribute Team team, Model model) {
        teamService.createTeam(team);
        model.addAttribute("message", "Team created successfully!");
        return "team_create"; // Redirect or show confirmation
    }

    @GetMapping("/{id}")
    public String getTeam(@PathVariable Long id, Model model) {
        model.addAttribute("team", teamService.getTeam(id).orElse(null));
        return "team_details"; // Thymeleaf template to show team details
    }

    @PostMapping("/delete/{id}")
    public String deleteTeam(@PathVariable Long id, Model model) {
        teamService.deleteTeam(id);
        model.addAttribute("message", "Team deleted successfully!");
        return "team_list"; // Thymeleaf template to show updated team list
    }
}

