package com.example.Task14;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeamService {
    @Autowired
    private TeamRepository teamRepository;

    public Team createTeam(Team team) {
        return teamRepository.save(team);
    }

    public Optional<Team> getTeam(Long id) {
        return teamRepository.findById(id);
    }

    public void deleteTeam(Long id) {
        teamRepository.deleteById(id);
    }
}