package com.example.Task14;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/coaches")
public class CoachController {
    @Autowired
    private CoachService coachService;

    @GetMapping("/create")
    public String showCreateCoachForm(Model model) {
        model.addAttribute("coach", new Coach());
        return "coach_create"; // Thymeleaf template for creating a coach
    }

    @PostMapping("/create")
    public String createCoach(@ModelAttribute Coach coach, Model model) {
        coachService.createCoach(coach);
        model.addAttribute("message", "Coach created successfully!");
        return "coach_create"; // Redirect or show confirmation
    }

    @GetMapping("/{id}")
    public String getCoach(@PathVariable Long id, Model model) {
        model.addAttribute("coach", coachService.getCoach(id).orElse(null));
        return "coach_details"; // Thymeleaf template to show coach details
    }

    @PostMapping("/delete/{id}")
    public String deleteCoach(@PathVariable Long id, Model model) {
        coachService.deleteCoach(id);
        model.addAttribute("message", "Coach deleted successfully!");
        return "coach_list"; // Thymeleaf template to show updated coach list
    }
}

